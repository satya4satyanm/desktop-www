console.log(
  '%c %c %c %c %c By satya4satyanm %c Phaser 3 @ https://codecanyon.net/user/techdyno',
  'background: #ff0000',
  'background: #ffff00',
  'background: #00ff00',
  'background: #00ffff',
  'color: #fff; background: #000000;',
  'background: none'
)
