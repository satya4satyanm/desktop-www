// import React from "react";
export const consts = {
  FOUNDATION: "FOUNDATION",
  TABLEAU: "TABLEAU",

  HEART: "HEART",
  CLOVER: "CLOVER",
  TILE: "TILE",
  PIKE: "PIKE"
};
