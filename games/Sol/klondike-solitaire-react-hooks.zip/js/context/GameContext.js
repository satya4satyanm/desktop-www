import React from "react";

const GameContext = React.createContext(null);

export default GameContext;
